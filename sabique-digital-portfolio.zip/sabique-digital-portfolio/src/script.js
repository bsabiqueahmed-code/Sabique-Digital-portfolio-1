// Form Handling

document.getElementById("infoForm").addEventListener("submit", function(e) {

  e.preventDefault();

  let name = document.getElementById("name").value;

  let email = document.getElementById("email").value;

  let phone = document.getElementById("phone").value;

  let message = document.getElementById("message").value;

  let output = `

    <h4>Thank you for submitting your details!</h4>

    <p><b>Name:</b> ${name}</p>

    <p><b>Email:</b> ${email}</p>

    <p><b>Phone:</b> ${phone}</p>

    <p><b>Message:</b> ${message}</p>

  `;

  document.getElementById("formOutput").innerHTML = output;

  // Reset form

  document.getElementById("infoForm").reset();

});